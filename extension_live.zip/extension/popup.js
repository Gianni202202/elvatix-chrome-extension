let iframe;
let iframe_url = 'https://elvatix.com/extension_page';
let width = 800;
let height = 580;

let iframe_onload = function () {
    let loading = document.getElementsByClassName('lds-ring')[0];
    loading.remove();
}

window.onload = async function () {
    function getCookie(name) {
        return new Promise((resolve, reject) => {
            chrome.cookies.get({ url: "https://www.linkedin.com", name: name }, function (cookie) {
                if (cookie) {
                    resolve(cookie.value);
                } else {
                    resolve(null);
                }
            });
        });
    }

    const liAtCookie = await getCookie("li_at");
    const liACookie = await getCookie("li_a");

    setTimeout(function () {
        chrome.tabs.query({ active: true, lastFocusedWindow: true }, async function (tabs) {
            var currentTab = tabs[0];
            var currentUrl = currentTab.url;
            let group = document.getElementsByClassName('group_iframe')[0];
            const agent = navigator.userAgent;
            let i = document.createElement('iframe');
            i.frameBorder = 0;
            i.width = width;
            i.height = height;
            i.src = iframe_url + `?url=${encodeURIComponent(currentUrl)}&userAgent=${agent}&liat=${liAtCookie}&lia=${liACookie}`;
            console.log(i.src);
            i.onload = iframe_onload;
            iframe = group.appendChild(i);
        });
    }, 100);
}
